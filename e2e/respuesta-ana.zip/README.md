# Solucion
API de inventario minima.
